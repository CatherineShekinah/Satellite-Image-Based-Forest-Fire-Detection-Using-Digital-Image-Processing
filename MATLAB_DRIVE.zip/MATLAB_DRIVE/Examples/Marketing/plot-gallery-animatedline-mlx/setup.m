
edit('PlotGallery_animatedline.mlx');
