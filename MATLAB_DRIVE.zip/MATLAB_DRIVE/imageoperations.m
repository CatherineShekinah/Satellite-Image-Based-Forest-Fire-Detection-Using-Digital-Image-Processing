abc = imread('abc.jpg'); 
xyz = imread('flower.jpg');
gray1 = rgb2gray(abc);
gray2 = rgb2gray(xyz);
gray2 = imresize(gray2, size(gray1));
bw1 = imbinarize(gray1);
bw2 = imbinarize(gray2);
added_img = imadd(gray1, gray2);           
multiplied_img = immultiply(gray1, gray2); 
and_img = bw1 & bw2;
or_img  = bw1 | bw2;
not_img = ~bw1;
figure;
subplot(3,3,1); imshow(gray1); title('Image 1');
subplot(3,3,2); imshow(gray2); title('Image 2 ');
subplot(3,3,3); imshow(added_img); title('Addition');
subplot(3,3,4); imshow(multiplied_img, []); title('Multiplication'); % Use [] to scale image for display
subplot(3,3,5); imshow(and_img); title('Logical AND');
subplot(3,3,6); imshow(or_img); title('Logical OR');
subplot(3,3,7); imshow(not_img); title('Logical NOT');

