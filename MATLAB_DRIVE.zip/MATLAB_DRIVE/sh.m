% Superheterodyne AM/FM Receiver Simulation in MATLAB

clc; clear; close all;

% Parameters
fs = 1e6;  % Sampling frequency (1 MHz)
t = 0:1/fs:5e-3; % Time vector (5 ms duration)
fc = 100e3;  % Carrier frequency (100 kHz)
fIF = 10e3;  % Intermediate frequency (10 kHz)
fm = 1e3;    % Modulating signal frequency (1 kHz)

% Generate AM and FM signals
m_am = cos(2*pi*fm*t); % Modulating signal (AM)
c_am = cos(2*pi*fc*t); % Carrier signal (AM)
s_am = (1 + 0.5*m_am) .* c_am; % AM signal

kf = 50; % Frequency deviation for FM
s_fm = cos(2*pi*fc*t + kf*sin(2*pi*fm*t)); % FM signal

% RF Amplification
s_am_rf = 2 * s_am; % Amplified AM signal
s_fm_rf = 2 * s_fm; % Amplified FM signal

% Mixing stage (Multiply with local oscillator)
fLO = fc - fIF; % Local oscillator frequency
lo = cos(2*pi*fLO*t); % Local oscillator signal
s_am_mixed = s_am_rf .* lo;
s_fm_mixed = s_fm_rf .* lo;

% Low-pass filter (IF filtering stage)
[b, a] = butter(5, (fIF*2)/fs, 'low');
s_am_if = filter(b, a, s_am_mixed);
s_fm_if = filter(b, a, s_fm_mixed);

% Plot results
figure;
subplot(3,1,1);
plot(t, s_am, 'b'); hold on;
plot(t, s_fm, 'r');
title('AM and FM Signals'); xlabel('Time (s)'); ylabel('Amplitude');
legend('AM', 'FM');

subplot(3,1,2);
plot(t, s_am_mixed, 'b'); hold on;
plot(t, s_fm_mixed, 'r');
title('Mixed Signals (After LO)'); xlabel('Time (s)'); ylabel('Amplitude');
legend('AM Mixed', 'FM Mixed');

subplot(3,1,3);
plot(t, s_am_if, 'b'); hold on;
plot(t, s_fm_if, 'r');
title('IF Signals (Filtered)'); xlabel('Time (s)'); ylabel('Amplitude');
legend('AM IF', 'FM IF');

sgtitle('Superheterodyne Receiver Simulation');
