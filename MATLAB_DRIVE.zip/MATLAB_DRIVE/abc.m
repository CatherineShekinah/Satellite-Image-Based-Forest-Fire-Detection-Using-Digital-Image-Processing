img = imread('sptiz.jpg');  
h_smooth = fspecial('average', [5 5]);   
smooth_img = imfilter(img_double, h_smooth, 'replicate');
h_lap = fspecial('laplacian', 0.2);  
laplacian_img = imfilter(img_double, h_lap, 'replicate');
sharp_img = img_double - laplacian_img; 
figure;
subplot(1,3,1);
imshow(img);
title('Original Image');
subplot(1,3,2);
imshow(smooth_img);
title('Smoothed Image');
subplot(1,3,3);
imshow(sharp_img);
title('Sharpened Image')