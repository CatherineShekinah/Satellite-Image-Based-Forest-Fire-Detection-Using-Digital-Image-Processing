clc; clear; close all;

% Sampling and time vector
fs = 50e3;
t = 0:1/fs:0.05; % total time = 0.05 s

% User Inputs
fm = input('Enter Message Signal Frequency (Hz): ');
fc = input('Enter Carrier Frequency (Hz): ');
Am = input('Enter Message Signal Amplitude: ');
Ac = input('Enter Carrier Amplitude: ');
kf = input('Enter FM Modulation Index: ');
SNR = input('Enter Signal-to-Noise Ratio (dB): ');

% Signal Definitions
m = Am * cos(2 * pi * fm * t);                  % Message Signal
c = Ac * cos(2 * pi * fc * t);                  % Carrier Signal
am_signal = (Ac + m) .* cos(2 * pi * fc * t);   % AM Modulated Signal

% FM Modulation
integrated_m = cumsum(m) / fs;                  % Integration of message
fm_signal = Ac * cos(2 * pi * fc * t + 2 * pi * kf * integrated_m);

% Add Noise
noise_am = randn(size(am_signal)) * std(am_signal) / db2mag(SNR);
noise_fm = randn(size(fm_signal)) * std(fm_signal) / db2mag(SNR);
am_noisy = am_signal + noise_am;
fm_noisy = fm_signal + noise_fm;

% ---------- Limit time to 0 to 0.01 s for plotting ----------
t_plot = t(t <= 0.01);
m_plot = m(t <= 0.01);
c_plot = c(t <= 0.01);
am_signal_plot = am_signal(t <= 0.01);
fm_signal_plot = fm_signal(t <= 0.01);
am_noisy_plot = am_noisy(t <= 0.01);
fm_noisy_plot = fm_noisy(t <= 0.01);

% ---------- TIME DOMAIN PLOTS ----------
figure('Name','Time Domain Signals','NumberTitle','off');

subplot(4,1,1);
plot(t_plot, m_plot); title('Message Signal'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(4,1,2);
plot(t_plot, c_plot); title('Carrier Signal'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(4,1,3);
plot(t_plot, am_signal_plot); title('AM Signal (Before Noise)'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(4,1,4);
plot(t_plot, fm_signal_plot); title('FM Signal (Before Noise)'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

% ---------- TIME DOMAIN COMPARISON WITH NOISE ----------
figure('Name','Noisy Signals (0 to 0.01 s)','NumberTitle','off');

subplot(2,1,1);
plot(t_plot, am_noisy_plot); title('AM Signal with Noise'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(2,1,2);
plot(t_plot, fm_noisy_plot); title('FM Signal with Noise'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

% ---------- FREQUENCY DOMAIN ANALYSIS ----------
N = length(t);
f = (-N/2:N/2-1)*(fs/N);

AM_spectrum = abs(fftshift(fft(am_noisy)))/N