img = imread('yourimage.jpg');   
R = img(:,:,1);                  
G = img(:,:,2);                 
B = img(:,:,3);                 

subplot(2,2,1), imshow(img), title('Original')
subplot(2,2,2), imshow(R), title('Red Channel')
subplot(2,2,3), imshow(G), title('Green Channel')
subplot(2,2,4), imshow(B), title('Blue Channel')