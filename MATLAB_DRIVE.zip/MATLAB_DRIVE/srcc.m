clc;
disp('Catherine - URK23EC1020');
disp('Generation of DT Sine Wave and Sample Rate Conversion');

% Define time and original signal
t = 0:0.1:2*pi;
a = sin(t);

% Plot original sine wave
subplot(3, 3, 1);
stem(t, a);
xlabel('Time');
ylabel('Amplitude');
title('Original Sine Wave');

% Interpolation (Upsampling)
y_interp = interp(a, 3);
t_interp = linspace(min(t), max(t), length(y_interp));
subplot(3, 3, 2);
stem(t_interp, y_interp);
xlabel('Time');
ylabel('Amplitude');
title('Interpolated Wave');

% Decimation (Downsampling with low-pass filtering)
y_dec = decimate(a, 2);
t_dec = linspace(min(t), max(t), length(y_dec));
subplot(3, 3, 3);
stem(t_dec, y_dec);
xlabel('Time');
ylabel('Amplitude');
title('Decimated Wave');

% Downsampling without filtering
y_down = downsample(a, 3);
t_down = t(1:3:end); % Downsample the time vector accordingly
subplot(3, 3, 4);
stem(t_down, y_down);
xlabel('Time');
ylabel('Amplitude');
title('Downsampled Wave');

% Resampling
[y_res, t_res] = resample(a, 3, 5); % Resample with specified rates
subplot(3, 3, 5);
stem(t_res, y_res);
xlabel('Time');
ylabel('Amplitude');
title('Resampled Wave');
