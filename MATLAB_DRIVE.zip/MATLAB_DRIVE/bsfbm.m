n=input('Enter the value for order ');
w=input('Enter the cutoff frequency ');
r=fir1(n-1,w/pi,'stop',blackman(n));
c=tf(r,1,1,'variable','z^-1');
disp(c);
freqz(r);
