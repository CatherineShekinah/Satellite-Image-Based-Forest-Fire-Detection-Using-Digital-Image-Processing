clc; clear; close all;

% Taking inputs from the user
fs = 50e3; % Reduced Sampling frequency for MATLAB Online compatibility
t = 0:1/fs:0.05; % Time vector (50 ms)

fm = input('Enter Message Signal Frequency (Hz): '); % Message frequency
fc = input('Enter Carrier Frequency (Hz): '); % Carrier frequency
Am = input('Enter Message Signal Amplitude: '); % Message amplitude
Ac = input('Enter Carrier Amplitude: '); % Carrier amplitude
kf = input('Enter FM Modulation Index: '); % FM modulation index

% Message Signal
m = Am * cos(2 * pi * fm * t);

% AM Modulation
am_signal = (Ac + m) .* cos(2 * pi * fc * t);

% FM Modulation
integrated_m = cumsum(m) / fs; % Integral of message signal
fm_signal = Ac * cos(2 * pi * fc * t + 2 * pi * kf * integrated_m);

% Plot Signals
figure;
subplot(3,1,1);
plot(t, m);
title('Message Signal'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(3,1,2);
plot(t, am_signal);
title('AM Signal'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(3,1,3);
plot(t, fm_signal);
title('FM Signal'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;
