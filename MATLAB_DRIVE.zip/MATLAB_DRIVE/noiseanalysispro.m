
clc; clear; close all;

fs = 50e3;                 
t = 0:1/fs:0.005;             

fm = input('Enter Message Signal Frequency (Hz): ');
fc = input('Enter Carrier Frequency (Hz): ');
Am = input('Enter Message Signal Amplitude: ');
Ac = input('Enter Carrier Amplitude: ');
kf = input('Enter FM Modulation Index: ');
SNR = input('Enter Signal-to-Noise Ratio (dB): ');

m = Am * cos(2 * pi * fm * t);                         
c = Ac * cos(2 * pi * fc * t);                         
am_signal = (Ac + m) .* cos(2 * pi * fc * t);          

delta_f = kf * fm;                     
kf_rad = 2 * pi * delta_f / Am;         
integrated_m = cumsum(m) / fs;          
fm_signal = Ac * cos(2 * pi * fc * t + kf_rad * integrated_m);

noise_am = randn(size(am_signal)) * std(am_signal) / db2mag(SNR);
noise_fm = randn(size(fm_signal)) * std(fm_signal) / db2mag(SNR);

am_noisy = am_signal + noise_am;
fm_noisy = fm_signal + noise_fm;

am_demod = abs(hilbert(am_noisy));
am_demod = am_demod - mean(am_demod); 

analytic_fm = hilbert(fm_noisy);
inst_phase = unwrap(angle(analytic_fm));
inst_freq = diff(inst_phase) * fs / (2 * pi);   
inst_freq = [inst_freq, inst_freq(end)];      
fm_demod = (inst_freq - fc) / kf;             

index_10ms = find(t <= 0.5);
t_plot = t(index_10ms);
m_plot = m(index_10ms);
am_clean_plot = am_signal(index_10ms);
fm_clean_plot = fm_signal(index_10ms);
am_demod_plot = am_demod(index_10ms);
fm_demod_plot = fm_demod(index_10ms);
am_noisy_plot = am_noisy(index_10ms);
fm_noisy_plot = fm_noisy(index_10ms);

index_zoom = find(t <= 0.5);
t_zoom = t(index_zoom);
c_zoom = c(index_zoom);
fm_zoom = fm_signal(index_zoom);

figure('Name','Time-Domain Signals (0–0.01 s)','NumberTitle','off');

subplot(4,2,1);
plot(t_plot, m_plot, 'b', 'LineWidth', 1.2); 
title('Message Signal'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(4,2,2);
plot(t_zoom, c_zoom, 'r', 'LineWidth', 1.5); 
title('Carrier Signal '); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(4,2,3);
plot(t_plot, am_clean_plot, 'g', 'LineWidth', 1.2); 
title('AM Signal '); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(4,2,4);
plot(t_zoom, fm_zoom, 'm', 'LineWidth', 1.5); 
title('FM Signal '); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(4,2,5);
plot(t_plot, am_noisy_plot, 'c', 'LineWidth', 1.2); 
title('AM Signal (Noisy)'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(4,2,6);
plot(t_plot, fm_noisy_plot, 'k', 'LineWidth', 1.2); 
title('FM Signal (Noisy)'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(4,2,7);
plot(t_plot, am_demod_plot, 'c', 'LineWidth', 1.2); 
title('AM Demodulated Signal'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(4,2,8);
plot(t_plot, fm_demod_plot, 'k', 'LineWidth', 1.2); 
title('FM Demodulated Signal'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

N = length(t);
f = (-N/2:N/2-1)*(fs/N);
AM_spectrum = abs(fftshift(fft(am_noisy)))/N;
FM_spectrum = abs(fftshift(fft(fm_noisy)))/N;

figure('Name','Frequency Spectrum','NumberTitle','off');
subplot(2,1,1);
plot(f, AM_spectrum); 
title('Frequency Spectrum of AM Signal'); xlabel('Frequency (Hz)'); ylabel('Magnitude'); grid on;

subplot(2,1,2);
plot(f, FM_spectrum); 
title('Frequency Spectrum of FM Signal'); xlabel('Frequency (Hz)'); ylabel('Magnitude'); grid on;

figure('Name','Power Spectral Density','NumberTitle','off');
subplot(2,1,1);
pwelch(am_noisy, [], [], [], fs);
title('PSD of AM Signal (Noisy)');

subplot(2,1,2);
pwelch(fm_noisy, [], [], [], fs);
title('PSD of FM Signal (Noisy)');

snr_am = snr(am_signal, noise_am);
snr_fm = snr(fm_signal, noise_fm);
fprintf('\nSNR for AM Signal: %.2f dB\n', snr_am);
fprintf('SNR for FM Signal: %.2f dB\n', snr_fm);
