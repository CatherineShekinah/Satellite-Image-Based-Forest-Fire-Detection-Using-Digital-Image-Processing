img = imread('cricket.jpg'); 
if size(img,3) == 3
    gray_img = rgb2gray(img);
else
    gray_img = img;
end
se = strel('square', 3);
eroded_img = imerode(bw, se);
boundary = bw - eroded_img;
se1 = [0 1 0; 1 1 1; 0 1 0];
se2 = [1 0 1; 0 0 0; 1 0 1];
hitmiss = bwhitmiss(bw, se1, se2);
filled_img = imfill(bw, 'holes');
[L, num] = bwlabel(bw);
colored_labels = label2rgb(L, 'jet', 'k', 'shuffle');
convex_img = bwconvhull(bw, 'objects');
figure;
subplot(2,3,1), imshow(img), title('Original Image');
subplot(2,3,2), imshow(boundary), title('Boundary Extraction');
subplot(2,3,3), imshow(hitmiss), title('Hit-or-Miss Transform');
subplot(2,3,4), imshow(filled_img), title('Region Filling');
subplot(2,3,5), imshow(colored_labels), title(['Connected Components = ', num2str(num)]);
subplot(2,3,6), imshow(convex_img), title('Convex Hull');

