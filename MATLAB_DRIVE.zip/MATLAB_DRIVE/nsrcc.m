clc;
disp('Catherine- URK23EC1020')
disp('Generation of DT Sine Wave and Sample rate Conversion');

t = [0:0.1:2*pi];
a = sin(t);

subplot(3,3,1);
stem(t, a);
xlabel('no of samples');
ylabel('amplitude');
title('Sine Wave');

y = interp(a, 3); 
t_interp = linspace(min(t), max(t), length(y)); 
subplot(3,3,2);
stem(t_interp, y);
xlabel('no of samples');
ylabel('amplitude');
title('Interpolated Wave');


y = decimate(a, 2); 
t_dec = linspace(min(t), max(t), length(y)); 
subplot(3,3,3);
stem(t_dec, y);
xlabel('no of samples');
ylabel('amplitude');
title('Decimated Wave');

y = downsample(a, 3); 
t_down = t(1:3:end); 
subplot(3,3,4);
stem(t_down, y);
xlabel('no of samples');
ylabel('amplitude');
title('Downsampled Wave');

y = resample(a, 3, 5); 
t_res = linspace(min(t), max(t), length(y)); 
subplot(3,3,5);
stem(t_res, y);
xlabel('no of samples');
ylabel('amplitude');
title('Resampled Wave');
