x = input('Enter the values of x(n): ');
disp('x(n):');
disp(x);
c=1:length(x);
subplot(2,2,1);

stem(c,x);
title('x(n)');
xlabel('No of samples');
ylabel('Amplitude');
N = length(x);
for k = 0:N-1
    sum= 0;
    for n = 0:N-1
        sum = sum + x(n+1) * exp(-1j * 2*pi*k*n/N);
    end
    X(k+1) = sum;
end
disp('X(k):');
disp(X);
subplot(2,2,2);

stem(c,X);
title('X(k)');
xlabel('No of samples');
ylabel('Amplitude');
o=abs(X);
disp(o);
subplot(2,2,3);

stem(c,o);
title('Magnitude using formula');
xlabel('No of samples');
ylabel('Amplitude');
b=fft(x,N);
disp('FFT');
disp(b);
disp('absolute value');
l=abs(b);
disp(l);
subplot(2,2,4);

stem(c,l);
title('Magnitude using fft');
xlabel('No of samples');
ylabel('Amplitude')