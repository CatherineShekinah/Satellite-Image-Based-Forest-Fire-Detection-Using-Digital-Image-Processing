clc; clear; close all;

% Taking inputs from the user
fs = 50e3; % Reduced Sampling frequency for MATLAB Online compatibility
t = 0:1/fs:0.05; % Time vector (50 ms)

fm = input('Enter Message Signal Frequency (Hz): '); % Message frequency
fc = input('Enter Carrier Frequency (Hz): '); % Carrier frequency
Am = input('Enter Message Signal Amplitude: '); % Message amplitude
Ac = input('Enter Carrier Amplitude: '); % Carrier amplitude
kf = input('Enter FM Modulation Index: '); % FM modulation index
SNR = input('Enter Signal-to-Noise Ratio (dB): '); % SNR

% Message Signal
m = Am * cos(2 * pi * fm * t);

% AM Modulation
am_signal = (Ac + m) .* cos(2 * pi * fc * t);

% FM Modulation
integrated_m = cumsum(m) / fs; % Integral of message signal
fm_signal = Ac * cos(2 * pi * fc * t + 2 * pi * kf * integrated_m);

% Adding Noise (Manual Calculation for MATLAB Online Compatibility)
noise_am = randn(size(am_signal)) * std(am_signal) / db2mag(SNR);
am_noisy = am_signal + noise_am;
noise_fm = randn(size(fm_signal)) * std(fm_signal) / db2mag(SNR);
fm_noisy = fm_signal + noise_fm;

% Plot Signals
figure; drawnow;
subplot(3,1,1);
plot(t, m);
title('Message Signal'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

drawnow;
subplot(3,1,2);
plot(t, am_noisy);
title('Noisy AM Signal'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

drawnow;
subplot(3,1,3);
plot(t, fm_noisy);
title('Noisy FM Signal'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

% Spectral Analysis (FFT)
N = length(t);
f = (-N/2:N/2-1)*(fs/N); % Frequency axis
AM_spectrum = abs(fftshift(fft(am_noisy)))/N;
FM_spectrum = abs(fftshift(fft(fm_noisy)))/N;

figure;
subplot(2,1,1);
plot(f, AM_spectrum);
title('Spectrum of Noisy AM Signal'); xlabel('Frequency (Hz)'); ylabel('Magnitude'); grid on;

subplot(2,1,2);
plot(f, FM_spectrum);
title('Spectrum of Noisy FM Signal'); xlabel('Frequency (Hz)'); ylabel('Magnitude'); grid on;

% Compute Power Spectral Density (PSD)
figure;
subplot(2,1,1);
pwelch(am_noisy, [], [], [], fs);
title('Power Spectral Density of Noisy AM Signal');

subplot(2,1,2);
pwelch(fm_noisy, [], [], [], fs);
title('Power Spectral Density of Noisy FM Signal');

% SNR Calculation
snr_am = snr(am_signal, noise_am);
snr_fm = snr(fm_signal, noise_fm);

fprintf('SNR for AM Signal: %.2f dB\n', snr_am);
fprintf('SNR for FM Signal: %.2f dB\n', snr_fm);
