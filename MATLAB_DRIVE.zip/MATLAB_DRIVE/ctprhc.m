clc; clear; close all;


fs = 50e3; 
t = 0:1/fs:0.05; 

fm = input('Enter Message Signal Frequency (Hz): '); 
fc = input('Enter Carrier Frequency (Hz): ');
Am = input('Enter Message Signal Amplitude: ');
Ac = input('Enter Carrier Amplitude: '); 
kf = input('Enter FM Modulation Index: '); 

m = Am * cos(2 * pi * fm * t);


am_signal = (Ac + m) .* cos(2 * pi * fc * t);


integrated_m = cumsum(m) / fs; 
fm_signal = Ac * cos(2 * pi * fc * t + 2 * pi * kf * integrated_m);


figure;
subplot(3,1,1);
plot(t, m);
title('Message Signal'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(3,1,2);
plot(t, am_signal);
title('AM Signal'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(3,1,3);
plot(t, fm_signal);
title('FM Signal'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;
