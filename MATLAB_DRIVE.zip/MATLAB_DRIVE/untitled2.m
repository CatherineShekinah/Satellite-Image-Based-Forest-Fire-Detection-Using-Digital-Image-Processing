clc; clear; close all;

%% AM Receiver Simulation
Fs = 100e3; % Sampling Frequency
T = 0.1; % Duration (s)
t = 0:1/Fs:T; % Time vector
fc = 10e3; % Carrier Frequency
m = cos(2*pi*100*t); % Message Signal (100 Hz)

% AM Modulation
am_mod = (1 + m) .* cos(2*pi*fc*t);

% Add AWGN Noise
am_mod_noisy = awgn(am_mod, 20, 'measured');

% AM Demodulation using Envelope Detection
am_demod = abs(hilbert(am_mod_noisy));

% Plot AM Signals
figure;
subplot(3,1,1); plot(t, m); title('Message Signal (AM)');
subplot(3,1,2); plot(t, am_mod_noisy); title('Noisy AM Signal');
subplot(3,1,3); plot(t, am_demod); title('Demodulated AM Signal');

%% FM Receiver Simulation
kf = 50; % Frequency deviation
fm_mod = fmmod(m, fc, Fs, kf); % FM Modulation
fm_mod_noisy = awgn(fm_mod, 20, 'measured'); % Add Noise
fm_demod = fmdemod(fm_mod_noisy, fc, Fs, kf); % FM Demodulation

% Plot FM Signals
figure;
subplot(3,1,1); plot(t, m); title('Message Signal (FM)');
subplot(3,1,2); plot(t, fm_mod_noisy); title('Noisy FM Signal');
subplot(3,1,3); plot(t, fm_demod); title('Demodulated FM Signal');

%% QPSK Receiver Simulation
M = 4; % QPSK Modulation Order
data = randi([0 M-1], 1000, 1); % Random Bit Sequence
txSig = pskmod(data, M, pi/4); % QPSK Modulation

% Transmit over AWGN Channel
rxSig = awgn(txSig, 10, 'measured');

% QPSK Demodulation
rxData = pskdemod(rxSig, M, pi/4);

% Bit Error Rate Calculation
[numErrors, ber] = biterr(data, rxData);
disp(['Bit Error Rate: ', num2str(ber)]);

% Constellation Diagram
scatterplot(rxSig); title('QPSK Constellation Diagram');
