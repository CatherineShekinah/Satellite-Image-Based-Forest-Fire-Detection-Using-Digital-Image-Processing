
img = imread('peppers.png');   % Change to your image
gray = rgb2gray(img);

% ----- Smoothing -----
% 1. Averaging filter
avg_filter = fspecial('average', [5 5]);
smooth_avg = imfilter(gray, avg_filter);



% ----- Sharpening -----
% 1. Laplacian filter
lap_filter = fspecial('laplacian', 0.2);
sharp_lap = imfilter(gray, lap_filter);
sharp_lap = imsubtract(gray, sharp_lap); % subtract Laplacian from original



% ----- Display -----
figure;
subplot(2,3,1), imshow(gray), title('Original Image');
subplot(2,3,2), imshow(smooth_avg), title('Smoothing: Average Filter');
subplot(2,3,4), imshow(uint8(sharp_lap)), title('Sharpening: Laplacian');
subplot(2,3,5), imshow(uint8(sobel_edges)), title('Sobel Edges');
subplot(2,3,6), imshow(uint8(sobel_enhanced)), title('Sobel Enhanced');
