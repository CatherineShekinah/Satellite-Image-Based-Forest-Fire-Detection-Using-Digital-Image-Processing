Clc:
disp('Catherine- URK23EC1020');
x = input('Enter the values of x(n): ');
disp('x(n):');
disp(x);
N = length(x);
c = 0:N-1; 
subplot(3,3,1);
stem(c, x);
title('x(n)');
xlabel('No of samples');
ylabel('Amplitude');
X = zeros(1, N);
for k = 0:N-1
    sum = 0;
    for n = 0:N-1
        sum = sum + x(n+1) * exp(-1j * 2*pi*k*n/N);
    end
    X(k+1) = sum; 
end
disp('X(k):');
disp(X);
subplot(3,3,2);
stem(c, X);
title('X(k)');
xlabel('No of samples');
ylabel('Amplitude');
o = abs(X);
disp(o);
subplot(3,3,3);
stem(c, o);
title('Magnitude');
xlabel('No of samples');
ylabel('Amplitude');
b = fft(x, N);
disp('FFT:');
disp(b);
subplot(3,3,4);
stem(c, b);
title('X(k)');
xlabel('No of samples');
ylabel('Amplitude');
disp('absolute value');
l = abs(b);
disp(l);
subplot(3,3,5);
stem(c, l);
title('Magnitude');
xlabel('No of samples');
ylabel('Amplitude');
