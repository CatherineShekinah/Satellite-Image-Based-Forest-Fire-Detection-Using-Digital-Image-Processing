x = input('Enter the values of x(n): ');
disp('x(n):');
disp(x);
c = 1:length(x);
subplot(2,2,1);
stem(c,x);
title('x(n)');
xlabel('No of samples');
ylabel('Amplitude');

N = length(x);
X = zeros(1,N);   % Initialize X

for k = 0:N-1
    temp_sum = 0; % Avoid using "sum"
    for n = 0:N-1
        temp_sum = temp_sum + x(n+1) * exp(-1j * 2*pi*k*n/N);
    end
    X(k+1) = temp_sum;
end

o = abs(X);
disp(o);
subplot(2,2,2);
stem(c,o);
title('Magnitude using formula');
xlabel('No of samples');
ylabel('Amplitude');

b = fft(x,N);
disp('FFT');
disp(b);

disp('absolute value');
l = abs(b);
disp(l);
subplot(2,2,3);
stem(c,l);
title('Magnitude using fft');
xlabel('No of samples');
ylabel('Amplitude');

