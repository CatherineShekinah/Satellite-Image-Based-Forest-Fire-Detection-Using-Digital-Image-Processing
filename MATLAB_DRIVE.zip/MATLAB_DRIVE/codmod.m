clc; clear; close all;

% Sampling setup
fs = 50e3;                   % Sampling frequency
t = 0:1/fs:0.05;             % Time vector (50 ms total)

% ---- USER INPUTS ----
fm = input('Enter Message Signal Frequency (Hz): ');
fc = input('Enter Carrier Frequency (Hz): ');
Am = input('Enter Message Signal Amplitude: ');
Ac = input('Enter Carrier Amplitude: ');
kf = input('Enter FM Modulation Index: ');
SNR = input('Enter Signal-to-Noise Ratio (dB): ');

% ---- SIGNAL DEFINITIONS ----
m = Am * cos(2 * pi * fm * t);                   % Message Signal
c = Ac * cos(2 * pi * fc * t);                   % Carrier Signal
am_signal = (Ac + m) .* cos(2 * pi * fc * t);    % AM Signal
integrated_m = cumsum(m)/fs;                     % Integration for FM
fm_signal = Ac * cos(2 * pi * fc * t + 2 * pi * kf * integrated_m); % FM Signal

% ---- NOISE ADDITION ----
noise_am = randn(size(am_signal)) * std(am_signal) / db2mag(SNR);
noise_fm = randn(size(fm_signal)) * std(fm_signal) / db2mag(SNR);
am_noisy = am_signal + noise_am;
fm_noisy = fm_signal + noise_fm;

% ---- LIMIT PLOTTING TO 0-0.01 s ----
t_plot = t(t <= 0.01);
m_plot = m(t <= 0.01);
c_plot = c(t <= 0.01);
am_clean_plot = am_signal(t <= 0.01);
fm_clean_plot = fm_signal(t <= 0.01);
am_noisy_plot = am_noisy(t <= 0.01);
fm_noisy_plot = fm_noisy(t <= 0.01);

% ---- TIME-DOMAIN PLOTS ----
figure('Name','Time-Domain Signals (0–0.01 s)','NumberTitle','off');

subplot(4,1,1);
plot(t_plot, m_plot); title('Message Signal'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(4,1,2);
plot(t_plot, c_plot); title('Carrier Signal'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(4,1,3);
plot(t_plot, am_clean_plot); title('AM Signal (Clean)'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(4,1,4);
plot(t_plot, fm_clean_plot); title('FM Signal (Clean)'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

% ---- NOISY SIGNALS (0–0.01 s) ----
figure('Name','Noisy Signals (0–0.01 s)','NumberTitle','off');

subplot(2,1,1);
plot(t_plot, am_noisy_plot); title('AM Signal with Noise'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(2,1,2);
plot(t_plot, fm_noisy_plot); title('FM Signal with Noise'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

% ---- FREQUENCY SPECTRUM ----
N = length(t);
f = (-N/2:N/2-1)*(fs/N);
AM_spectrum = abs(fftshift(fft(am_noisy)))/N;
FM_spectrum = abs(fftshift(fft(fm_noisy)))/N;

figure('Name','Frequency Spectrum','NumberTitle','off');
subplot(2,1,1);
plot(f, AM_spectrum); title('Spectrum of AM Signal (Noisy)'); xlabel('Frequency (Hz)'); ylabel('Magnitude'); grid on;

subplot(2,1,2);
plot(f, FM_spectrum); title('Spectrum of FM Signal (Noisy)'); xlabel('Frequency (Hz)'); ylabel('Magnitude'); grid on;

% ---- POWER SPECTRAL DENSITY ----
figure('Name','Power Spectral Density','NumberTitle','off');

subplot(2,1,1);
pwelch(am_noisy, [], [], [], fs); title('PSD of AM Signal (Noisy)');

subplot(2,1,2);
pwelch(fm_noisy, [], [], [], fs); title('PSD of FM Signal (Noisy)');

% ---- SNR PRINT ----
snr_am = snr(am_signal, noise_am);
snr_fm = snr(fm_signal, noise_fm);

fprintf('\nSNR for AM Signal: %.2f dB\n', snr_am);
fprintf('SNR for FM Signal: %.2f dB\n', snr_fm);