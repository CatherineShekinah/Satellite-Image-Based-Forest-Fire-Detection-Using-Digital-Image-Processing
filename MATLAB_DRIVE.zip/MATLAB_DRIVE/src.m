clc;
disp('Catherine- URK23EC1020')
disp('Generation of DT Sine Wave and Sample rate Conversion');
t = [0:0.1:2*pi]
a = sin(t);
subplot(3,3,1);
stem(t,a)
xlabel('time')
ylabel('amplitude')
title('Sine Wave')
t = [0:0.1:2*pi]
a = sin(t);
subplot(3,3,2);
stem(y);
y = interp(a,3);
xlabel('time')
ylabel('amplitude')
title('Interpolated Wave')
t = [0:0.1:2*pi]
a = sin(t);
subplot(3,3,3);
stem(y)
y = decimate(a,2);
xlabel('time')
ylabel('amplitude')
title('Decimated Wave')
t = [0:0.1:2*pi]
a = sin(t);
subplot(3,3,4);
stem(y)
y = downsample(a,3)
xlabel('time')
ylabel('amplitude')
title('Downsampled Wave')
t = [0:0.1:2*pi]
a = sin(t);
subplot(3,3,5);
stem(y)
y = resample(a,3,5)
xlabel('time')
ylabel('amplitude')
title('Resampled Wave')