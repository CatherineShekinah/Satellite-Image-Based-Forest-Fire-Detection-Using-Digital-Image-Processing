clc; clear; close all;

% Sampling and time vector
fs = 50e3;
t = 0:1/fs:0.05;

% User Inputs
fm = input('Enter Message Signal Frequency (Hz): ');
fc = input('Enter Carrier Frequency (Hz): ');
Am = input('Enter Message Signal Amplitude: ');
Ac = input('Enter Carrier Amplitude: ');
kf = input('Enter FM Modulation Index: ');
SNR = input('Enter Signal-to-Noise Ratio (dB): ');

% Signal Definitions
m = Am * cos(2 * pi * fm * t);                  % Message Signal
c = Ac * cos(2 * pi * fc * t);                  % Carrier Signal
am_signal = (Ac + m) .* cos(2 * pi * fc * t);   % AM Modulated Signal

% FM Modulation
integrated_m = cumsum(m) / fs;                  % Integration of message
fm_signal = Ac * cos(2 * pi * fc * t + 2 * pi * kf * integrated_m);

% Add Noise
noise_am = randn(size(am_signal)) * std(am_signal) / db2mag(SNR);
noise_fm = randn(size(fm_signal)) * std(fm_signal) / db2mag(SNR);
am_noisy = am_signal + noise_am;
fm_noisy = fm_signal + noise_fm;

% ---------- TIME DOMAIN PLOTS ----------
figure('Name','Time Domain Signals','NumberTitle','off');

subplot(4,1,1);
plot(t, m); title('Message Signal'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(4,1,2);
plot(t, c); title('Carrier Signal'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(4,1,3);
plot(t, am_signal); title('AM Signal (Before Noise)'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(4,1,4);
plot(t, fm_signal); title('FM Signal (Before Noise)'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

% ---------- TIME DOMAIN COMPARISON WITH NOISE ----------
figure('Name','Noisy Signals','NumberTitle','off');

subplot(2,1,1);
plot(t, am_noisy); title('AM Signal with Noise'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(2,1,2);
plot(t, fm_noisy); title('FM Signal with Noise'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

% ---------- FREQUENCY DOMAIN ANALYSIS ----------
N = length(t);
f = (-N/2:N/2-1)*(fs/N);

AM_spectrum = abs(fftshift(fft(am_noisy)))/N;
FM_spectrum = abs(fftshift(fft(fm_noisy)))/N;

figure('Name','Frequency Spectrum','NumberTitle','off');
subplot(2,1,1);
plot(f, AM_spectrum); title('Spectrum of Noisy AM Signal'); xlabel('Frequency (Hz)'); ylabel('Magnitude'); grid on;

subplot(2,1,2);
plot(f, FM_spectrum); title('Spectrum of Noisy FM Signal'); xlabel('Frequency (Hz)'); ylabel('Magnitude'); grid on;

% ---------- POWER SPECTRAL DENSITY ----------
figure('Name','Power Spectral Density','NumberTitle','off');
subplot(2,1,1);
pwelch(am_noisy, [], [], [], fs); title('PSD of Noisy AM Signal');

subplot(2,1,2);
pwelch(fm_noisy, [], [], [], fs); title('PSD of Noisy FM Signal');

% ---------- SNR CALCULATION ----------
snr_am = snr(am_signal, noise_am);
snr_fm = snr(fm_signal, noise_fm);

fprintf('SNR for AM Signal: %.2f dB\n', snr_am);
fprintf('SNR for FM Signal: %.2f dB\n', snr_fm);
