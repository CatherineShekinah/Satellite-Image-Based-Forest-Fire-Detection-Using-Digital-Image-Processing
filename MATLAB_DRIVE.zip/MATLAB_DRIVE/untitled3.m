clc;
disp('Catherine- URK23EC1020')
disp('Generation of DT Sine Wave and Sample rate Conversion');

t = [0:0.1:2*pi];
a = sin(t);

subplot(3,3,1);
stem(t, a);
xlabel('no of samples');
ylabel('amplitude');
title('Sine Wave');

y = interp(a, 3);
t = linspace(0, 2*pi, length(y)); 
subplot(3,3,2);
stem(t, y);
xlabel('no of samples');
ylabel('amplitude');
title('Interpolated Wave');


y = decimate(a, 2); 
t = linspace(0, 2*pi, length(y)); 
subplot(3,3,3);
stem(t, y);
xlabel('no of samples');
ylabel('amplitude');
title('Decimated Wave');


y = downsample(a, 3);
t = t(1:3:end); 
subplot(3,3,4);
stem(t, y);
xlabel('no of samples');
ylabel('amplitude');
title('Downsampled Wave');


y = resample(a, 3, 5); 
t = linspace(0, 2*pi, length(y)); 
subplot(3,3,5);
stem(t, y);
xlabel('no of samples');
ylabel('amplitude');
title('Resampled Wave');
