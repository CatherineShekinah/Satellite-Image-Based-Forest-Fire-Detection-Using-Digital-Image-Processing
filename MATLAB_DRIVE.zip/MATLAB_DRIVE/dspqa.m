clc; clear; close all;

%% Step 1: Load ECG Signal
fs = 360; % Sampling frequency (Hz) - MIT-BIH database standard
t = 0:1/fs:10; % Time vector (10 seconds)

% Simulated ECG waveform (sum of sinusoids mimicking heartbeats)
ecg_input = 0.6*sin(2*pi*1.2*t) + 0.4*sin(2*pi*2.5*t) + 0.2*randn(size(t));

% If using real ECG data, uncomment the following:
% load('ecg.mat'); % Load real ECG dataset (Ensure 'ecg.mat' contains 'ecg' variable)
% ecg_input = ecg; % Assign loaded ECG signal
% fs = 360; % Modify as per dataset
% t = (0:length(ecg_input)-1)/fs; % Adjust time vector

%% Step 2: Preprocess ECG (Optional - Can Add Filters)
ecg_signal = ecg_input; % For now, use the input signal directly

%% Step 3: Compute FFT
N = length(ecg_signal); % Number of samples
f = (0:N-1)*(fs/N); % Frequency vector
ecg_fft = fft(ecg_signal); % Compute FFT

% Compute magnitude spectrum
ecg_magnitude = abs(ecg_fft)/N;

%% Step 4: Create Subplots
figure;

% Subplot 1: Input ECG Signal
subplot(3,1,1);
plot(t, ecg_input, 'k'); % Black color
xlabel('Time (s)');
ylabel('Amplitude');
title('Input ECG Signal');
grid on;
xlim([0 5]); % Display first 5 seconds

% Subplot 2: Time-Domain Processed ECG Signal
subplot(3,1,2);
plot(t, ecg_signal, 'b'); % Blue color
xlabel('Time (s)');
ylabel('Amplitude');
title('Time-Domain ECG Signal');
grid on;
xlim([0 5]); % Display first 5 seconds

% Subplot 3: Frequency-Domain ECG Signal (FFT)
subplot(3,1,3);
plot(f(1:N/2), ecg_magnitude(1:N/2), 'r'); % Red color
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Frequency-Domain ECG Signal (FFT)');
grid on;
xlim([0 50]); % Show up to 50 Hz (relevant ECG frequencies)


