% Read the uploaded image
img = imread('nature.jpg');  % Change the extension if it's .png or .jpeg

% Check if the image is RGB, and convert to grayscale if needed
if size(img, 3) == 3
    gray_img = rgb2gray(img);  % Convert RGB to grayscale
else
    gray_img = img;            % Already grayscale
end

% Display the grayscale image
imshow(gray_img);
title('Grayscale Image');
