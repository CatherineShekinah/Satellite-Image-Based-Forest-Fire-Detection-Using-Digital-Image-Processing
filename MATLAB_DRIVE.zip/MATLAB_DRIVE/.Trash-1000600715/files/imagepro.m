img = imread('abc.jpg');


% Step 2: Convert to grayscale (only if it's a color image)
if size(img, 3) == 3
    gray_img = rgb2gray(img);   % Convert RGB to grayscale
else
    gray_img = img;             % Already grayscale
end

% Step 3: Display the grayscale image
imshow(gray_img);
title('Grayscale Image');

