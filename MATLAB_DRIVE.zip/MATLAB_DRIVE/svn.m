clc;
disp('Catherine- URK23EC1020')
disp('Generation of DT Sine Wave and Sample rate Conversion');

% Original time vector and sine wave
t = [0:0.1:2*pi];
a = sin(t);

% Plot original sine wave
subplot(3,3,1);
stem(t, a);
xlabel('time');
ylabel('amplitude');
title('Sine Wave');

% Interpolation
y = interp(a, 3); % Interpolated signal
t = linspace(0, 2*pi, length(y)); % Adjust time vector
subplot(3,3,2);
stem(t, y);
xlabel('time');
ylabel('amplitude');
title('Interpolated Wave');

% Decimation
y = decimate(a, 2); % Decimated signal
t = linspace(0, 2*pi, length(y)); % Adjust time vector
subplot(3,3,3);
stem(t, y);
xlabel('time');
ylabel('amplitude');
title('Decimated Wave');

% Downsampling
y = downsample(a, 3); % Downsampled signal
t = t(1:3:end); % Adjust time vector
subplot(3,3,4);
stem(t, y);
xlabel('time');
ylabel('amplitude');
title('Downsampled Wave');

% Resampling
y = resample(a, 3, 5); % Resampled signal
t = linspace(0, 2*pi, length(y)); % Adjust time vector
subplot(3,3,5);
stem(t, y);
xlabel('time');
ylabel('amplitude');
title('Resampled Wave');
