clc; clear; close all;

% Define Parameters
fs = 100e3;        % Sampling frequency (100 kHz)
t = 0:1/fs:0.02;   % Time vector (20 ms duration)
fm = 200;          % Message frequency (200 Hz)
fc = 10e3;         % Carrier frequency (10 kHz)
kf = 50;           % Frequency deviation constant

% Generate Message Signal (Sinusoidal)
msg = cos(2 * pi * fm * t);

% FM Modulation
fm_modulated = fmmod(msg, fc, fs, kf * max(msg));

% Add AWGN Noise
snr_values = [5, 10, 15, 20];  % Different SNR levels
figure;
for i = 1:length(snr_values)
    noisy_signal = awgn(fm_modulated, snr_values(i), 'measured');

    % FM Demodulation
    demodulated_signal = fmdemod(noisy_signal, fc, fs, kf);

    % Plot Results
    subplot(length(snr_values),1,i);
    plot(t, demodulated_signal, 'b');
    title(['FM Demodulated Signal with SNR = ', num2str(snr_values(i)), ' dB']);
    xlabel('Time (s)');
    ylabel('Amplitude');
    grid on;
end

% Calculate SNR of the demodulated signal
snr_demodulated = snr(demodulated_signal, msg - demodulated_signal);
disp(['SNR of Demodulated Signal: ', num2str(snr_demodulated), ' dB']);
