img = imread('nature.jpg');  
if size(img, 3) == 3
    gray_img = rgb2gray(img);
else
    gray_img = img; 
end
imshow(gray_img);
title('Grayscale Image');
figure;
imshow(gray_img);
title('Grayscale Image');
