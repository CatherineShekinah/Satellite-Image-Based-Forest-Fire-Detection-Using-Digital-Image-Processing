clc; clear; close all;

%% Step 1: Set folder names (relative to current MATLAB folder)
fireFolder = 'fire/';       % folder with fire images
nonFireFolder = 'nonfire/';  % folder with no-fire images

%% Step 2: Get all image files (jpg, jpeg, png)
types = {'*.jpg','*.jpeg','*.png'};

fireFiles = [];
for i = 1:length(types)
    fireFiles = [fireFiles; dir(fullfile(fireFolder, types{i}))];
end

nonFireFiles = [];
for i = 1:length(types)
    nonFireFiles = [nonFireFiles; dir(fullfile(nonFireFolder, types{i}))];
end

disp(['Number of fire images: ', num2str(length(fireFiles))]);
disp(['Number of nonfire images: ', num2str(length(nonFireFiles))]);

%% Step 3: Preprocess Function
resizeSize = [256 256];  % resize all images to 256x256
preprocessImage = @(img) im2double(imresize(img, resizeSize));  % resize + normalize

%% Step 4: Read and preprocess Fire Images
fireImages = [];
for k = 1:length(fireFiles)
    img = imread(fullfile(fireFolder, fireFiles(k).name));
    
    % Convert grayscale to RGB if needed
    if size(img,3) == 1
        img = cat(3,img,img,img);
    end
    
    % Resize and normalize
    img = preprocessImage(img);
    
    % Store in 4D array
    fireImages(:,:,:,k) = img;
end

%% Step 5: Read and preprocess No-Fire Images
noFireImages = [];
for k = 1:length(nonFireFiles)
    img = imread(fullfile(nonFireFolder, nonFireFiles(k).name));
    
    % Convert grayscale to RGB if needed
    if size(img,3) == 1
        img = cat(3,img,img,img);
    end
    
    % Resize and normalize
    img = preprocessImage(img);
    
    % Store in 4D array
    nonFireImages(:,:,:,k) = img;
end

%% Step 6: Check output
disp(['Processed fire images: ', num2str(size(fireImages,4))]);
disp(['Processed nonfire images: ', num2str(size(nonFireImages,4))]);

% Display one example fire image
figure; imshow(fireImages(:,:,:,1));
title('Example Preprocessed Fire Image');

% Display one example no-fire image
figure; imshow(nonFireImages(:,:,:,1));
title('Example Preprocessed NonFire Image');

%% ------------------- Step C: Feature Extraction -------------------
% Feature: Mean R, G, B values
extractColorFeatures = @(img) [mean2(img(:,:,1)) mean2(img(:,:,2)) mean2(img(:,:,3))];

% Fire features
X_fire = zeros(length(fireFiles),3); % each row: [R_mean G_mean B_mean]
for k = 1:size(fireImages,4)
    X_fire(k,:) = extractColorFeatures(fireImages(:,:,:,k));
end

% No-Fire features
X_nonFire = zeros(length(nonFireFiles),3);
for k = 1:size(nonFireImages,4)
    X_nonFire(k,:) = extractColorFeatures(nonFireImages(:,:,:,k));
end

% Combine features and labels
X = [X_fire; X_nonFire];
y = [ones(size(X_fire,1),1); zeros(size(X_nonFire,1),1)]; % 1=fire, 0=no-fire

%% Display some results
disp('Example feature vector for first fire image:');
disp(X_fire(1,:));

disp('Example feature vector for first no-fire image:');
disp(X_nonFire(1,:));

disp('Feature matrix X size:');
disp(size(X));
disp('Label vector y size:');
disp(size(y));

%% ------------------- Step D: Train Random Forest Classifier -------------------

% Step D1: Split data into training and testing (80% train, 20% test)
cv = cvpartition(y,'HoldOut',0.2);
X_train = X(training(cv),:);
y_train = y(training(cv));
X_test = X(test(cv),:);
y_test = y(test(cv));

% Step D2: Train Random Forest
numTrees = 100;  % number of trees in the forest
RFModel = TreeBagger(numTrees, X_train, y_train, 'Method','classification', 'OOBPrediction','On');

% Step D3: Predict on test set
y_pred = str2double(predict(RFModel, X_test));  % convert cell array output to numeric

% Step D4: Calculate accuracy
accuracy = sum(y_pred == y_test)/length(y_test);
disp(['Random Forest Accuracy: ', num2str(accuracy*100), '%']);

% Step D5: Show predictions for first 5 test images
disp('Predictions for first 5 test images:');
disp(y_pred(1:min(5,length(y_pred))));
disp('Actual labels for first 5 test images:');
disp(y_test(1:min(5,length(y_test))));

% Predict labels for the test set
y_pred = str2double(predict(RFModel, X_test));

% Calculate accuracy
accuracy = sum(y_pred == y_test)/length(y_test);
disp(['Test Set Accuracy: ', num2str(accuracy*100), '%']);

% Display predictions for first 5 test images
disp('Predicted labels for first 5 test images:');
disp(y_pred(1:min(5,length(y_pred))));
disp('Actual labels for first 5 test images:');
disp(y_test(1:min(5,length(y_test))));

%% Step F: Fire Region Visualization

% Step 1: Select a new image
[newFile, newPath] = uigetfile({'*.jpg;*.jpeg;*.png'}, 'Select an image to visualize fire');
if isequal(newFile,0)
    disp('No file selected');
    return;  % stop execution if no image is selected
else
    newImg = imread(fullfile(newPath,newFile));
end

% Step 2: Preprocess image (resize + normalize + convert to RGB)
if size(newImg,3) == 1
    newImg = cat(3,newImg,newImg,newImg);  % convert grayscale to RGB
end
newImg = im2double(imresize(newImg, [256 256]));

% Step 3: Display the original selected image
figure; imshow(newImg);
title('Original Selected Image');

% Step 4: Create fire mask (red channel threshold)
fireMask = newImg(:,:,1) > 0.6;  

% Step 5: Optional: smooth the mask
fireMask = imdilate(fireMask, strel('disk',2));

% Step 6: Highlight fire pixels in red
visualImg = newImg;
visualImg(:,:,1) = visualImg(:,:,1) + fireMask;    % increase red
visualImg(:,:,2) = visualImg(:,:,2) .* ~fireMask;   % reduce green
visualImg(:,:,3) = visualImg(:,:,3) .* ~fireMask;   % reduce blue
visualImg = min(visualImg,1);  % clip values to [0 1]

% Step 7: Display the highlighted fire regions
figure; imshow(visualImg);
title('Fire Regions Highlighted in Red');
