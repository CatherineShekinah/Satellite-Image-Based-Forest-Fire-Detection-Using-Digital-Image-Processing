Wp = 0.628;
Ws = 1.884;
Rp = 0.75;
Rs = 4.89;
[N, Wn] = cheb1ord(Wp, Ws, Rp, Rs, 's');
disp('Order: ');
disp(N);
[B, A] = cheby1(N,Rp,Wp,'s');


[X, Y] = impinvar(B, A);
subplot(1,2,2);
freqz(X,Y);