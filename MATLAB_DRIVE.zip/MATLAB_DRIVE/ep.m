n=input('Enter the value of the order:');
w=input('Enter the cutoff frequency:');
h=fir1(n-1,w/pi,'high',hamming(n));
b=tf(h,1,1,'variable','z^-1');
disp(b);
freqz(h);
