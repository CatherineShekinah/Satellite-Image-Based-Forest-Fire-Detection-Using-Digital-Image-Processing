clc; clear; close 
fs = 50e3;                   % Sampling frequency
t = 0:1/fs:0.05;             % Time vector (50 ms total)

% ---- USER INPUTS ----
fm = input('Enter Message Signal Frequency (Hz): ');
fc = input('Enter Carrier Frequency (Hz): ');
Am = input('Enter Message Signal Amplitude: ');
Ac = input('Enter Carrier Amplitude: ');
kf = input('Enter FM Modulation Index: ');
SNR = input('Enter Signal-to-Noise Ratio (dB): ');

% ---- SIGNAL DEFINITIONS ----
m = Am * cos(2 * pi * fm * t);                   % Message Signal
c = Ac * cos(2 * pi * fc * t);                   % Carrier Signal
am_signal = (Ac + m) .* cos(2 * pi * fc * t);    % AM Signal
integrated_m = cumsum(m)/fs;                     % Integration for FM
fm_signal = Ac * cos(2 * pi * fc * t + 2 * pi * kf * integrated_m); % FM Signal

% ---- NOISE ADDITION ----
noise_am = randn(size(am_signal)) * std(am_signal) / db2mag(SNR);
noise_fm = randn(size(fm_signal)) * std(fm_signal) / db2mag(SNR);
am_noisy = am_signal + noise_am;
fm_noisy = fm_signal + noise_fm;

% ---- LIMIT TIME RANGE TO 0 - 0.01 s FOR PLOTTING ----
index_limit = find(t <= 0.01);
t_plot = t(index_limit);
m_plot = m(index_limit);
c_plot = c(index_limit);
am_clean_plot = am_signal(index_limit);
fm_clean_plot = fm_signal(index_limit);
am_noisy_plot = am_noisy(index_limit);
fm_noisy_plot = fm_noisy(index_limit);

% ---- ALL TIME-DOMAIN SIGNALS IN ONE FIGURE ----
figure('Name','All Time-Domain Signals (0–0.01 s)','NumberTitle','off');

subplot(3,2,1);
plot(t_plot, m_plot, 'b'); title('Message Signal'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(3,2,2);
plot(t_plot, c_plot, 'r'); title('Carrier Signal'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(3,2,3);
plot(t_plot, am_clean_plot, 'g'); title('AM Signal (Clean)'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(3,2,4);
plot(t_plot, fm_clean_plot, 'm'); title('FM Signal (Clean)'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(3,2,5);
plot(t_plot, am_noisy_plot, 'c'); title('AM Signal with Noise'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

subplot(3,2,6);
plot(t_plot, fm_noisy_plot, 'k'); title('FM Signal with Noise'); xlabel('Time (s)'); ylabel('Amplitude'); grid on;

% ---- FREQUENCY SPECTRUM ----
N = length(t);
f = (-N/2:N/2-1)*(fs/N);
AM_spectrum = abs(fftshift(fft(am_noisy)))/N;
FM_spectrum = abs(fftshift(fft(fm_noisy)))/N;

figure('Name','Frequency Spectrum','NumberTitle','off');
subplot(2,1,1);
plot(f, AM_spectrum); title('Spectrum of AM Signal (Noisy)'); xlabel('Frequency (Hz)'); ylabel('Magnitude'); grid on;

subplot(2,1,2);
plot(f, FM_spectrum); title('Spectrum of FM Signal (Noisy)'); xlabel('Frequency (Hz)'); ylabel('Magnitude'); grid on;

% ---- POWER SPECTRAL DENSITY ----
figure('Name','Power Spectral Density','NumberTitle','off');

subplot(2,1,1);
pwelch(am_noisy, [], [], [], fs); title('PSD of AM Signal (Noisy)');

subplot(2,1,2);
pwelch(fm_noisy, [], [], [], fs); title('PSD of FM Signal (Noisy)');

% ---- SNR PRINT ----
snr_am = snr(am_signal, noise_am);
snr_fm = snr(fm_signal, noise_fm);

fprintf('\nSNR for AM Signal: %.2f dB\n', snr_am);
fprintf('SNR for FM Signal: %.2f dB\n', snr_fm);